
EXEC tSQLt.Run 'testPracticalSQLQueries';