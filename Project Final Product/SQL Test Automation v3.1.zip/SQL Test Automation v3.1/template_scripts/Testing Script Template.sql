USE master;
-- USE [DATABASENAME];
GO

EXEC tSQLt.NewTestClass 'testSQLPracticalTest';
GO

CREATE PROCEDURE testSQLPracticalTest.[TEST QUESTION 02]
AS
BEGIN

	CREATE TABLE Actual (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	CREATE TABLE Expected (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	INSERT INTO Actual
	EXEC Question2;

	INSERT INTO Expected
	EXEC Question2_ModelAnswer

	EXEC tSQLt.AssertEqualsTable 'Expected', 'Actual', 'Incorrect Answer!';

END;
GO

CREATE PROCEDURE testSQLPracticalTest.[TEST QUESTION 03]
AS
BEGIN

	CREATE TABLE Actual (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	CREATE TABLE Expected (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	INSERT INTO Actual
	EXEC Question3;

	INSERT INTO Expected
	EXEC Question3_ModelAnswer

	EXEC tSQLt.AssertEqualsTable 'Expected', 'Actual', 'Incorrect Answer!';

END;
GO

CREATE PROCEDURE testSQLPracticalTest.[TEST QUESTION 04]
AS
BEGIN

	CREATE TABLE Actual (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	CREATE TABLE Expected (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	INSERT INTO Actual
	EXEC Question4;

	INSERT INTO Expected
	EXEC Question4_ModelAnswer

	EXEC tSQLt.AssertEqualsTable 'Expected', 'Actual', 'Incorrect Answer!';

END;
GO

CREATE PROCEDURE testSQLPracticalTest.[TEST QUESTION 05]
AS
BEGIN

	CREATE TABLE Actual (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	CREATE TABLE Expected (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	INSERT INTO Actual
	EXEC Question5;

	INSERT INTO Expected
	EXEC Question5_ModelAnswer

	EXEC tSQLt.AssertEqualsTable 'Expected', 'Actual', 'Incorrect Answer!';

END;
GO

CREATE PROCEDURE testSQLPracticalTest.[TEST QUESTION 06]
AS
BEGIN

	CREATE TABLE Actual (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	CREATE TABLE Expected (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	INSERT INTO Actual
	EXEC Question6;

	INSERT INTO Expected
	EXEC Question6_ModelAnswer

	EXEC tSQLt.AssertEqualsTable 'Expected', 'Actual', 'Incorrect Answer!';

END;
GO

CREATE PROCEDURE testSQLPracticalTest.[TEST QUESTION 07]
AS
BEGIN

	CREATE TABLE Actual (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	CREATE TABLE Expected (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	INSERT INTO Actual
	EXEC Question7;

	INSERT INTO Expected
	EXEC Question7_ModelAnswer

	EXEC tSQLt.AssertEqualsTable 'Expected', 'Actual', 'Incorrect Answer!';

END;
GO

CREATE PROCEDURE testSQLPracticalTest.[TEST QUESTION 08]
AS
BEGIN

	CREATE TABLE Actual (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	CREATE TABLE Expected (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	INSERT INTO Actual
	EXEC Question8;

	INSERT INTO Expected
	EXEC Question8_ModelAnswer

	EXEC tSQLt.AssertEqualsTable 'Expected', 'Actual', 'Incorrect Answer!';

END;
GO

CREATE PROCEDURE testSQLPracticalTest.[TEST QUESTION 09]
AS
BEGIN

	CREATE TABLE Actual (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	CREATE TABLE Expected (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	INSERT INTO Actual
	EXEC Question9;

	INSERT INTO Expected
	EXEC Question9_ModelAnswer

	EXEC tSQLt.AssertEqualsTable 'Expected', 'Actual', 'Incorrect Answer!';

END;
GO

CREATE PROCEDURE testSQLPracticalTest.[TEST QUESTION 10]
AS
BEGIN

	CREATE TABLE Actual (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	CREATE TABLE Expected (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	INSERT INTO Actual
	EXEC Question10;

	INSERT INTO Expected
	EXEC Question10_ModelAnswer

	EXEC tSQLt.AssertEqualsTable 'Expected', 'Actual', 'Incorrect Answer!';

END;
GO

CREATE PROCEDURE testSQLPracticalTest.[TEST QUESTION 11]
AS
BEGIN

	CREATE TABLE Actual (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	CREATE TABLE Expected (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	INSERT INTO Actual
	EXEC Question11;

	INSERT INTO Expected
	EXEC Question11_ModelAnswer

	EXEC tSQLt.AssertEqualsTable 'Expected', 'Actual', 'Incorrect Answer!';

END;
GO

CREATE PROCEDURE testSQLPracticalTest.[TEST QUESTION 12]
AS
BEGIN

	CREATE TABLE Actual (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	CREATE TABLE Expected (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	INSERT INTO Actual
	EXEC Question12;

	INSERT INTO Expected
	EXEC Question12_ModelAnswer

	EXEC tSQLt.AssertEqualsTable 'Expected', 'Actual', 'Incorrect Answer!';

END;
GO

CREATE PROCEDURE testSQLPracticalTest.[TEST QUESTION 13]
AS
BEGIN

	CREATE TABLE Actual (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	CREATE TABLE Expected (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	INSERT INTO Actual
	EXEC Question13;

	INSERT INTO Expected
	EXEC Question13_ModelAnswer

	EXEC tSQLt.AssertEqualsTable 'Expected', 'Actual', 'Incorrect Answer!';

END;
GO

CREATE PROCEDURE testSQLPracticalTest.[TEST QUESTION 14]
AS
BEGIN

	CREATE TABLE Actual (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	CREATE TABLE Expected (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	INSERT INTO Actual
	EXEC Question14;

	INSERT INTO Expected
	EXEC Question14_ModelAnswer

	EXEC tSQLt.AssertEqualsTable 'Expected', 'Actual', 'Incorrect Answer!';

END;
GO

CREATE PROCEDURE testSQLPracticalTest.[TEST QUESTION 15]
AS
BEGIN

	CREATE TABLE Actual (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	CREATE TABLE Expected (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	INSERT INTO Actual
	EXEC Question15;

	INSERT INTO Expected
	EXEC Question15_ModelAnswer

	EXEC tSQLt.AssertEqualsTable 'Expected', 'Actual', 'Incorrect Answer!';

END;
GO

CREATE PROCEDURE testSQLPracticalTest.[TEST QUESTION 16]
AS
BEGIN

	CREATE TABLE Actual (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	CREATE TABLE Expected (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	INSERT INTO Actual
	EXEC Question16;

	INSERT INTO Expected
	EXEC Question16_ModelAnswer

	EXEC tSQLt.AssertEqualsTable 'Expected', 'Actual', 'Incorrect Answer!';

END;
GO

CREATE PROCEDURE testSQLPracticalTest.[TEST QUESTION 17]
AS
BEGIN

	CREATE TABLE Actual (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	CREATE TABLE Expected (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	INSERT INTO Actual
	EXEC Question17;

	INSERT INTO Expected
	EXEC Question17_ModelAnswer

	EXEC tSQLt.AssertEqualsTable 'Expected', 'Actual', 'Incorrect Answer!';

END;
GO

CREATE PROCEDURE testSQLPracticalTest.[TEST QUESTION 18]
AS
BEGIN

	CREATE TABLE Actual (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	CREATE TABLE Expected (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	INSERT INTO Actual
	EXEC Question18;

	INSERT INTO Expected
	EXEC Question18_ModelAnswer

	EXEC tSQLt.AssertEqualsTable 'Expected', 'Actual', 'Incorrect Answer!';

END;
GO

CREATE PROCEDURE testSQLPracticalTest.[TEST QUESTION 19]
AS
BEGIN

	CREATE TABLE Actual (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	CREATE TABLE Expected (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	INSERT INTO Actual
	EXEC Question19;

	INSERT INTO Expected
	EXEC Question19_ModelAnswer

	EXEC tSQLt.AssertEqualsTable 'Expected', 'Actual', 'Incorrect Answer!';

END;
GO

CREATE PROCEDURE testSQLPracticalTest.[TEST QUESTION 20]
AS
BEGIN

	CREATE TABLE Actual (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	CREATE TABLE Expected (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	INSERT INTO Actual
	EXEC Question20;

	INSERT INTO Expected
	EXEC Question20_ModelAnswer

	EXEC tSQLt.AssertEqualsTable 'Expected', 'Actual', 'Incorrect Answer!';

END;
GO

CREATE PROCEDURE testSQLPracticalTest.[TEST QUESTION 21]
AS
BEGIN

	CREATE TABLE Actual (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	CREATE TABLE Expected (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	INSERT INTO Actual
	EXEC Question21;

	INSERT INTO Expected
	EXEC Question21_ModelAnswer

	EXEC tSQLt.AssertEqualsTable 'Expected', 'Actual', 'Incorrect Answer!';

END;
GO

CREATE PROCEDURE testSQLPracticalTest.[TEST QUESTION 22]
AS
BEGIN

	CREATE TABLE Actual (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	CREATE TABLE Expected (
	-- COLUMNS EXPECTED FROM QUESTION HERE
	);

	INSERT INTO Actual
	EXEC Question22;

	INSERT INTO Expected
	EXEC Question22_ModelAnswer

	EXEC tSQLt.AssertEqualsTable 'Expected', 'Actual', 'Incorrect Answer!';

END;
GO


EXEC tSQLt.Run 'testSQLPracticalTest';