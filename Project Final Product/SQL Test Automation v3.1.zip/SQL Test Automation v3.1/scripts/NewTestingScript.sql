
EXEC tSQLt.Run 'testSQLPracticalTest';